import { ICluster, IClusterPropertySet } from 'modules/hercules/hybrid-services.types';
import { HybridServicesClusterService } from 'modules/hercules/services/hybrid-services-cluster.service';
import { ClusterCascadeBandwidthService } from './cluster-cascade-bandwidth.service';

export class ClusterCascadeBandwidthController implements ng.IComponentController {
  public hasMfTrustedSipToggle: boolean;
  public bandwidthChange: boolean = false;
  public inValidValue: boolean = true;
  public clusterId: string;
  public cluster: ICluster;
  public cascadeBandwidthConfiguration: number | 42;
  public bandwidthError: boolean = false;

  public clusterBandwidth = {
    title: 'mediaFusion.clusterBandwidth.title',
  };

  /* @ngInject */
  constructor(
    private HybridServicesClusterService: HybridServicesClusterService,
    private ClusterCascadeBandwidthService: ClusterCascadeBandwidthService,
  ) { }

  public $onChanges(changes: { [bindings: string]: ng.IChangesObject<any> }) {
    const { cluster } = changes;
    if (cluster && cluster.currentValue) {
      this.cluster = cluster.currentValue;
      this.clusterId = this.cluster.id;
      this.getProperties(this.clusterId);
    }
  }

  public validate() {
    // this.cascadeBandwidthConfiguration = '66';
    this.bandwidthChange = true;
    this.inValidValue = true;
    if (this.cascadeBandwidthConfiguration >= 5 && this.cascadeBandwidthConfiguration <= 55) {
      this.inValidValue = false;
      this.bandwidthError = false;
    } else {
      this.bandwidthError = true;
    }
  }

  private getProperties(clusterId) {
    this.HybridServicesClusterService.getProperties(clusterId)
      .then((properties: IClusterPropertySet) => {
        //if (!_.isUndefined(properties['mf.maxCascadeBandwidth'])) {
        const cascadeBandwidth = properties['mf.maxCascadeBandwidth'];
        this.cascadeBandwidthConfiguration = cascadeBandwidth ? cascadeBandwidth : this.cascadeBandwidthConfiguration;
        // this.cascadeBandwidthConfiguration = properties['mf.maxCascadeBandwidth'] as string;
        //}
      });
  }

  public saveCascadeConfig(): void {
    this.ClusterCascadeBandwidthService.saveCascadeConfig(this.clusterId, this.cascadeBandwidthConfiguration);
  }
}

export class ClusterCascadeBandwidthComponent implements ng.IComponentOptions {
  public controller = ClusterCascadeBandwidthController;
  public template = require('./cluster-cascade-bandwidth.html');
  public bindings = {
    cluster: '<',
  };
}
